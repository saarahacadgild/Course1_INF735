Course instructions can be found in v5.2 for all roles

Reading material is found in Books.

  9a. Building Microservices, 2nd Edition
  
  9b. Microsoft .NET Microservices Architecture Guide
  
